<div class="wrapper row4" style="background-color:#787878;">
  <footer id="footer" class="hoc clear"> 
    <!-- ################################################################################################ -->
    <div class="one_third first">
      <h6 class="heading" style="color:black; font-size:25px;text-align:left;">About Us</h6>
      <ul class="nospace btmspace-30 linklist contact">
        <li><i class="fa fa-map-marker"></i>
          <address style="font-size:20px; text-align:left;">
              New Basti,Clement Town,Dehradun-248002,uttarakhand(INDIA)
          </address>
        </li>
        <li style="font-size:20px; text-align:left;"><i class="fa fa-phone"></i> +91 982-1345-930</li>
        <li style="font-size:20px; text-align:left;"><i class="fa fa-envelope-o"></i> best@foodies.com</li>
      </ul>
      <ul class="faico clear" style="text-align:left;">
        <li ><a class="faicon-facebook" href="#" ><i class="fa fa-facebook" ></i></a></li>
        <li><a class="faicon-twitter" href="#"><i class="fa fa-twitter"></i></a></li>
        <li><a class="faicon-dribble" href="#"><i class="fa fa-dribbble"></i></a></li>
        <li><a class="faicon-linkedin" href="#"><i class="fa fa-linkedin"></i></a></li>
        <li><a class="faicon-google-plus" href="#"><i class="fa fa-google-plus"></i></a></li>
        <li><a class="faicon-vk" href="#"><i class="fa fa-vk"></i></a></li>
      </ul>
    </div>
    <div class="one_third">
      <h6 class="heading" style="font-size:25px; text-align:left;">Privacy Policies</h6>
      <ul class="nospace linklist">
        <li>
          <article style="font-size:20px; text-align:left;">
            <h2 class="nospace font-x1" style="font-size:20px; text-align:left;"><a href="#">Terms & Conditions</a></h2>
            <time class="font-xs block btmspace-10" datetime="2045-04-06" style="font-size:15px; text-align:left;">Friday, 6<sup>th</sup> April 2045</time>
            <p class="nospace" style="font-size:15px; text-align:left;">These terms and conditions include, amongst other things, a licence specifying how the website may be used, a disclaimer of liability, a statutory disclosures ...[&hellip;]</p>
          </article>

        </li>
		
        <li>
          <article>
            <h2 class="nospace font-x1" style="font-size:20px; text-align:left;"><a href="#">Policies</a></h2>
            <time class="font-xs block btmspace-10" datetime="2045-04-05" style="font-size:15px; text-align:left;">Thursday, 5<sup>th</sup> April 2045</time>
            <p class="nospace" style="font-size:15px; text-align:left;">A policy is a statement of intent, and is implemented as a procedure or protocol. Policies are generally adopted by the board of directors or senior governance body within an organization. [&hellip;]</p>
          </article>
        </li>
      </ul>
    </div>
    <div class="one_third" style="padding-left:50px;">
	
	 
	
      <h6  style="font-size:20px; text-align:left; color:#efefef; margin-top:30px;">Contact Us</h6>
      <p  style="font-size:15px; text-align:left;">For any query or complaint please tell us .</p>
   <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d110204.74637241579!2d77.94709406502764!3d30.32540979227568!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390929c356c888af%3A0x4c3562c032518799!2sDehradun%2C+Uttarakhand!5e0!3m2!1sen!2sin!4v1502534223957" width="400" height="300" frameborder="0" style="border:0" allowfullscreen></iframe>
    </div>  <!-- ################################################################################################ -->
  </footer>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper row5">
  <div id="copyright" class="hoc clear"> 
    <!-- ################################################################################################ -->
    <p class="fl_left">Best Foodies &copy; 2017 - All Rights Reserved - <a href="#">B.tech Student</a></p>
    <p class="fl_right">Template by <a target="_blank" href="http://www.os-templates.com/" title="Free Website Templates">OS Templates</a></p>
    <!-- ################################################################################################ -->
  </div>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>
<!-- JAVASCRIPTS -->
<script src="layout/scripts/jquery.min.js"></script>
<script src="layout/scripts/jquery.backtotop.js"></script>
<script src="layout/scripts/jquery.mobilemenu.js"></script>
</body>
</html>