<?php include("header.php");?>

  <!-- ################################################################################################ -->
  <!-- ################################################################################################ -->
  <!-- ################################################################################################ -->
 
  <div class="wrapper overlay">
    <article id="pageintro" class="hoc clear"style="z-index:0s;"> 
      <!-- ################################################################################################ -->
      <h1 class="heading" style="font-size:70px;">FROM FARM TO <br>PLATE,MAKE FOOD SAFE !!!</h1>
      <p>LoVe At FiRsT BitE:)
	
	     </p>
      <footer><a class="btn" href="#">Todays Menu</a></footer>
      <!-- ################################################################################################ -->
    </article>
  </div>
  <!-- ################################################################################################ -->
</div>
<!-- End Top Background Image Wrapper -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper row3" style="background-color:#3aacec;">
  <main class="hoc container clear"> 
    <!-- main body -->
    <!-- ################################################################################################ -->
    <div class="group" style="margin-left:20px;">
      <div class="one_half first" style="text-align:left;">
       
        <h6 class="heading" style="color:white; font-size:30px;">Our Speciality</h6>
        <p>While food delivery apps and online ordering for food at work rule the roost, there are still a good number of office-goers in Bengaluru who prefer to pack food from home to work. From saving on budget and loving home-cooked food to showing off culinary skills at work, the reasons are a mouthful..</p>
        
        <footer style="text-align:left;"><a class="btn" href="#" style="font-size:20px;">Read More &raquo;</a></footer>
      </div>
      <div class="one_half" >
        <ul class="nospace group">
          <li class="one_half first btmspace-50">
            <article>
              <h6 class="heading font-x1"><a href="#" style="color:white; font-size:20px;">Homely Feel</a></h6>
              <p class="nospace">Nothing tastes better than home-cooked food, says Ashwin Kumar, an IT professional.</p>
            </article>
          </li>
          <li class="one_half btmspace-50">
            <article>
              <h6 class="heading font-x1"><a href="#" style="color:white; font-size:20px;">Cleanliness</a></h6>
              <p class="nospace">A good lunch is only as good as you pack it. Use a partitioned or decked container to fit everything you need. And if you are sure you won’t need a side dish, avoid it.</p>
            </article>
          </li>
          <li class="one_half first">
            <article>
              <h6 class="heading font-x1"><a href="#" style="color:white; font-size:20px;">No One Hates the Home Food</a></h6>
              <p class="nospace">“We also get to try out various recipes and impress mom when she visits. She’s very proud that we are managing the budget well and saving up.” [&hellip;]</p>
            </article>
          </li>
          <li class="one_half">
            <article>
              <h6 class="heading font-x1"><a href="#" style="color:white; font-size:20px;">Change your routine</a></h6>
              <p class="nospace">Bringing the same lunches every week will bore you. Change your lunch plan every week. It’s also important to plan ahead a day in advance.</p>
            </article>
          </li>
        </ul>
      </div>
    </div>
    <!-- ################################################################################################ -->
    <!-- / main body -->
    <div class="clear"></div>
  </main>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper bgded" style="background-image:url('images/demo/backgrounds/pizza.jpg');">
  <div class="hoc split clear">
    <section> 
      <!-- ################################################################################################ -->
      <h2 class="heading">HEALTH WITH TASTE</h2>
      <p class="btmspace-50">“Your diet is a bank account.Good food choices are good investments” Make the smart choice by placing your order with Go Dabbas today!.</p>
      <ul class="nospace group elements">
        <li>
          <article><a href="#"><i class="fa fa-wpexplorer"></i></a>
            <h6 class="heading">Tiffin Service</h6>
            <p>Our Magic Box gets you habituated to us and leaves you yearning for more every-time. [&hellip;]</p>
            <footer><a href="#">View Details &raquo;</a></footer>
          </article>
        </li>
        <li>
          <article><a href="#"><i class="fa fa-eye-slash"></i></a>
            <h6 class="heading">HYGIENIC</h6>
            <p>Cooked in highly, Sanitized environment, Packed in disposable containers [&hellip;]</p>
            <footer><a href="#">View Details &raquo;</a></footer>
          </article>
        </li>
      </ul>
      <!-- ################################################################################################ -->
    </section>
  </div>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper bgded overlay coloured" style="background-image:url('images/demo/backgrounds/bg-3.jpg');">
  <section class="hoc container clear center">
    <div class="cta sectiontitle"> 
      <!-- ################################################################################################ -->
      <h3 class="heading"><strong>GO HEALTHY! EAT HEALTHY! BE HEALTHY!’</strong></h3>
      <p class="btmspace-50">At Yummy Tiffins, you get to choose whatever you like for your next meal. The menu does not feel repetitive anymore and you have a tasty well balanced affordable meal anywhere in Indian..</p>
      <footer><a class="btn" href="#">Tiffin Services Redifined</a></footer>
      <!-- ################################################################################################ -->
    </div>
  </section>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper row3" style="background-color:#efefef;">
  <section class="hoc container clear"> 
    <!-- ################################################################################################ -->
    <ul class="nospace group elements">
      <li class="one_third first">
        <article><a href="#"><i class="fa fa-plane"></i></a>
          <h6 class="heading">7 DAYS OPERATIONS</h6>
          <p>We will not let you go hungry. Ever.Your hunger will not take a break, so why should we?</p>
          <footer><a href="#">View Details &raquo;</a></footer>
        </article>
      </li>
      <li class="one_third">
        <article><a href="#"><i class="fa fa-wheelchair-alt"></i></a>
          <h6 class="heading">PROFESSIONAL MANAGEMENT</h6>
          <p>Blend of 9 years of learning from 3 great institutions: IIM Ahmedabad,Nokia & SMG Convonix Customer centricity. Strong processes. Smooth operations. No scale-up issues.</p>
          <footer><a href="#">View Details &raquo;</a></footer>
        </article>
      </li>
      <li class="one_third">
        <article><a href="#"><i class="fa fa-expeditedssl"></i></a>
          <h6 class="heading">FULLY OWNED SUPPLY CHAIN</h6>
          <p>Even Tiffin Delivery. Full control at lower costs. Standardized experience.We will try hard but in rare cases we fail, we will have no one else to blame but us</p>
          <footer><a href="#">View Details &raquo;</a></footer>
        </article>
      </li>
      <li class="one_third first">
        <article><a href="#"><i class="fa fa-envira"></i></a>
          <h6 class="heading">CRAZY CUSTOMIZATION</h6>
          <p>For us you are an individual & not just one of the many customers. No fixed plans or packages. Select items & pay only for what you want</p>
          <footer><a href="#">View Details &raquo;</a></footer>
        </article>
      </li>
      <li class="one_third">
        <article><a href="#"><i class="fa fa-paw"></i></a>
          <h6 class="heading">KICKASS CUSTOMER SERVICE</h6>
          <p>No false claims here. Give us a chance to see it for real.No compromises for existing customers to acquire & serve new customers</p>
          <footer><a href="#">View Details &raquo;</a></footer>
        </article>
      </li>
      <li class="one_third">
        <article><a href="#"><i class="fa fa-vine"></i></a>
          <h6 class="heading">VALUE FOR MONEY</h6>
          <p>Great quality & premium service at a very reasonable price. A wholesome meal at just Rs. 79 inclusive of taxes + Rs. 15 delivery charge"</p>
          <footer><a href="#">View Details &raquo;</a></footer>
        </article>
      </li>
    </ul>
    <!-- ################################################################################################ -->
  </section>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper bgded overlay" style="background-image:url('images/demo/backgrounds/bg-4.jpg');">
  <div class="hoc container testimonials clear"> 
    <!-- ################################################################################################ -->
    <article><img src="images/demo/kirti.jpg" alt="">
      <blockquote>We are complete newbies with no experience in the food industry. The only relationship we have had with food so far is to have eaten a lot of it. So when we think of our business we think as customers first: No saving costs, no cutting corners, no compromises. Just good Food, Service and Pricing that we as consumers would be satisfied with. </blockquote>
   
    <!-- ################################################################################################ -->
  </div>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper row3" style="background-color:#efefef;">
  <section class="hoc container clear"> 
    <!-- ################################################################################################ -->
    <div class="sectiontitle">
      <h6 class="heading" style="font-size:30px;">Start Your Tiffin Now</h6>
      <p style="font-size:17px;">Premium Quality Food & Top Class Service at a Very Cool Price</p>
    </div>
 
	
	<div style="padding:0px 30px 30px 30px; max-width:1000px;  overflow-x:auto; margin-top:50px;" >
	
	<div class="row">
		<?php
	
		$rows=$db->getMealDetails(0);
		while($r=mysqli_fetch_array($rows))
		{
			
            echo"<div class='col-md-4 col-sm-6 portfolio-item' style='background-color:#dedede; padding:10px;'>";
              echo"<a href='#portfolioModal1' class='portfolio-link' data-toggle='modal'>";
                     echo"<div class='portfolio-hover'>";
                            echo"<div class='portfolio-hover-content'>"; 
                          echo "</div>";
                       echo"</div>";
                        echo"<img src='backfoot/".$r["ImagePath"]."' class='img-responsive' alt='' style='height:190px; width:400px;'>";
                    echo"</a>";
                    echo"<div class='portfolio-caption'>";
                        echo"<h4>".$r["Name"]."</h4>";
                        echo"<p class='text-muted'><a href='#' style='color:white; text-decoration:none;'>".$r["Description"]."</a></p>";
                    echo"</div>";
                echo"</div>";
		}
		?>
		</div>
	
		</div>
		
	
	  <!--##################################### ####################################-->
	  <!--########################################  	echo"<article class='one_third first' style='margin-top:40px;'>";  echo"</article>";#################################-->
	  <!--#########################################################################-->
	
      </div>  
    <!-- ################################################################################################ -->
    <div class="clear"></div>
  </section>
</div>
<!--</div>-->


<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper bgded overlay light" style="background-image:url('images/demo/backgrounds/bg-5.jpg'); padding:40px;">
  <figure class="hoc clear"> 
    <!-- ################################################################################################ -->
    <ul class="nospace group logos">
      <li class="one_quarter first"><a href="#"><img src="images/demo/1.jpg" alt=""></a></li>
      <li class="one_quarter"><a href="#"><img src="images/demo/2.jpg" alt=""></a></li>
      <li class="one_quarter"><a href="#"><img src="images/demo/3.jpg" alt=""></a></li>
      <li class="one_quarter"><a href="#"><img src="images/demo/4.jpg" alt=""></a></li>
    </ul>
    <!-- ################################################################################################ -->
  </figure>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<?php include("footer.php");?>
  